#!/bin/bash

tempdata=`/usr/bin/iostat -yzkx 1 1 | grep $1 | head -1 | awk '{print $12}'`
if [ ! $tempdata ]
  then
   echo "0"
  else
   echo $tempdata
fi


