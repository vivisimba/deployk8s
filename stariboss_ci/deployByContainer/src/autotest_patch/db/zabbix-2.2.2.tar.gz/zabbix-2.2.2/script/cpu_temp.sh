#! /bin/bash

sensors | grep $1 | awk '{print $3}'|awk '{print substr($1,2,2)}'|awk 'BEGIN {max = 0} {if ($1+0 > max+0) max=$1} END {print max}'
