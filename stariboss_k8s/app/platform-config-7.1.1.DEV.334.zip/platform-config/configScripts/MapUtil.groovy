import com.star.common.config.Util;

config = Util.getMap(CONF)